<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
               <li><a class="menuitem">Tùy chọn trang web</a>
                    <ul class="submenu">
                        <li><a href="titleslogan.php">Tiêu đề & Khẩu hiệu</a></li>
                        <li><a href="social.php">Truyền thông xã hội</a></li>
                        <li><a href="copyright.php">Bản quyền</a></li>
                        
                    </ul>
                </li>
				
                 <li><a class="menuitem">Cập nhật trang</a>
                    <ul class="submenu">
                        
                        <li> <a> Giới thiệu về chúng tôi </a> </li>
                        <li> <a> Liên hệ với chúng tôi </a> </li>
                    </ul>
                </li>
				<li><a class="menuitem">Tùy chọn thanh trượt</a>
                    <ul class="submenu">
                        <li> <a href="slideradd.php"> Thêm Thanh trượt </a> </li>
                        <li> <a href="sliderlist.php"> Danh sách Thanh trượt </a> </li>
                    </ul>
                </li> 
                <li><a class="menuitem">Tùy chọn danh mục</a>
                    <ul class="submenu">
                        <li><a href="catadd.php">thêm thể loại</a> </li>
                        <li><a href="catlist.php">Danh sách chuyên mục</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Tùy chọn thương hiệu</a>
                    <ul class="submenu">
                        <li><a href="brandadd.php">Thêm nhãn hiệu</a> </li>
                        <li><a href="brandlist.php">Danh sách thương hiệu</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Tùy chọn sản phẩm</a>
                    <ul class="submenu">
                        <li><a href="productadd.php">Thêm sản phẩm</a> </li>
                        <li><a href="productlist.php">Danh sách sản phẩm</a> </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>