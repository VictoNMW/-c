 <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
         &copy; Copyright <a href="#">Trang mua sắm trực tuyến </a>. Đã đăng ký Bản quyền.
        </p>
    </div>
</body>
</html>
