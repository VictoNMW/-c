<?php

if (isset($_POST['submit']) && isset($_FILES['image'])) {
	
    $sname = "localhost";
    $uname = "root";
    $password = "";
    $db_name = "db_shop";
    
    $conn = mysqli_connect($sname, $uname, $password, $db_name);

    $video_name = $_FILES['image']['name'];
    $tmp_name = $_FILES['image']['tmp_name'];
    $error = $_FILES['image']['error'];

    if ($error === 0) {
    	$video_ex = pathinfo($video_name, PATHINFO_EXTENSION);

    	$video_ex_lc = strtolower($video_ex);

    	$allowed_exs = array("png", 'jpeg', 'jpg');

    	if (in_array($video_ex_lc, $allowed_exs)) {
    		
    		$new_video_name = uniqid("video-", true). '.'.$video_ex_lc;
    		$video_upload_path = 'silder/'.$new_video_name;
    		move_uploaded_file($tmp_name, $video_upload_path);
            $tiler = $_POST['title'];
            $sql = "INSERT INTO slider(imgSlider,title) 
                   VALUES('$new_video_name','$tiler')";
            mysqli_query($conn, $sql);
             header("Location:slideradd.php");
    	}else {
    		$em = "You can't upload files of this type";
    		header("Location: index.php?error=$em");
    	}
    }


}else{
	header("Location: index.php");
}
?>