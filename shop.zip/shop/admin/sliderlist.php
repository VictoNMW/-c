<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Danh sách thanh trượt</h2>
        <div class="block">  
            <table class="data display datatable" id="example">
			<thead>
				<tr>
					
					<th> Id. </th>
					<th> Tiêu đề Thanh trượt </th>
					<th> Hình ảnh Thanh trượt </th>
					<th> Hành động </th>
				</tr>
			</thead>
			<tbody>
			<?php 
							include "../inc/connectSlider.php";
							$sql = "SELECT * FROM slider ORDER BY id DESC";
							$res = mysqli_query($conn, $sql);

							if (mysqli_num_rows($res) > 0) {
								while ($video = mysqli_fetch_assoc($res)) {?>

				<tr class="odd gradeX">
					<td><?=$video['id'] ?></td>
					<td><?=$video['title'] ?></td>
					<td><img src="silder/<?=$video['imgSlider']?>" height="40px" width="60px"/></td>				
				<td>


				
					<form action="deleteSlider.php?id=<?php echo $video['id'];?>" method="post">
						<button onclick="return confirm('Bạn có chắc chắn muốn xóa!')" name="delete">Xóa</button>
					</form>
					<?php }} ?>
				</td>
					</tr>	
			</tbody>
		</table>

       </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
		setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php';?>
