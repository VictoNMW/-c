<?php
if (isset($_POST['delete'])) {
	
    $sname = "localhost";
    $uname = "root";
    $password = "";
    $db_name = "db_shop";

    $id = $_GET['id'];
    
    $conn = mysqli_connect($sname, $uname, $password, $db_name);
    $sql = "DELETE FROM `slider` WHERE id = $id";
    $res = mysqli_query($conn, $sql);
    if($res){
        header("location: sliderlist.php");
    }
}

?>