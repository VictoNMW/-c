<?php include 'inc/header.php';?>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$name = $fm->validation($_POST['name']);
	$email = $fm->validation($_POST['email']);
	$contact = $fm->validation($_POST['contact']);
	$message = $fm->validation($_POST['message']);
	

	$name = mysqli_real_escape_string($db->link, $name);
	$email = mysqli_real_escape_string($db->link, $email);
	$contact = mysqli_real_escape_string($db->link, $contact);
	$message = mysqli_real_escape_string($db->link, $message);

	$error = "";

	if (empty($name)) {
		$error = "Tên không được để trống !";
	} elseif (empty($email)) {
		$error = "Email không được để trống !";
	} elseif (empty($contact)) {
		$error = "Trường liên hệ không được để trống !";

	} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		$error = "Địa chỉ email không hợp lệ !";
	} elseif (empty($message)) {
		$error = "Trường chủ đề không được để trống !";

	} else {
 $query = "INSERT INTO tbl_contact(name,email,contact,message) VALUES('$name','$email','$contact','$message')";

    $inserted_rows = $db->insert($query);

    if ($inserted_rows) {
     $msg = "Đã gửi tin nhắn thành công.";

    }else {
    $error = "Tin nhắn chưa được gửi!";
    }
	}

	}

	?>





 <div class="main">
    <div class="content">
    	<div class="support">
  			<div class="support_desc">
  				<h3>Hỗ trợ trực tuyến</h3>
  				<p><span>24 giờ | 7 ngày trong tuần | 365 ngày một năm &nbsp;&nbsp; Hỗ trợ kỹ thuật trực tiếp</span></p>
  			</div>
  				<img src="images/contact.png" alt="" />
  			<div class="clear"></div>
  		</div>
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Liên hệ chúng tôi</h2>

				  <?php 
				if (isset($error)) {
					echo "<span style = 'color:red'>$error</span>";
				}

				if (isset($msg)) {
					echo "<span style = 'color:green'>$msg</span>";
				}


				?>
					    <form action="" method="post">
					    	<div>
						    	<span><label>Tên</label></span>
						    	<span><input type="text" name="name" value=""></span>
						    </div>
						    <div>
						    	<span><label>E-MAIL</label></span>
						    	<span><input type="text" name="email" value=""></span>
						    </div>
						    <div>
						     	<span><label>SDT</label></span>
						    	<span><input type="text" name="contact" value=""></span>
						    </div>
						    <div>
						    	<span><label>Chủ sở hữu</label></span>
						    	<span><textarea name="message"> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" name="submit" value="Gửi"></span>
						  </div>
					    </form>
				  </div>
  				</div>
				<div class="col span_1_of_3">
      			<div class="company_address">
				     	<h2>Thông tin công ty:</h2>
						    	<p></p>
						   		<p></p>
						   		<p></p>
				   		<p>Di dộng:0976666666</p>
				   		<p>hotline:0000000000</p>
				 	 	<p>Email: <span>nhom8@gmail.com</span></p>
				   		<p>Theo dõi chúng tôi: <span>Facebook</span>, <span>Twitter</span></p>
				   </div>
				 </div>
			  </div>    	
    </div>
 </div>
<?php include 'inc/footer.php';?>